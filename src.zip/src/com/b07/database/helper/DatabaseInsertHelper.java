package com.b07.database.helper;

import com.b07.collection.ItemTypes;
import com.b07.collection.Roles;
import com.b07.database.DatabaseInserter;
import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.InvalidInputInfoException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;


public class DatabaseInsertHelper extends DatabaseInserter {

  /**
   * insert the role types by the given name.
   * 
   * @param name the name of the roles.
   * @return the roleId if successful, -1 o/w.
   * @throws InvalidInputInfoException if the user inputs a duplicate or invalid role name.
   */
  public static int insertRole(String name) throws InvalidInputInfoException {
    int roleId = -1;
    // role is a duplicate
    boolean inRoleTable = DatabaseDriverHelper.inRoleTablebyName(name);
    if (inRoleTable == true) {
      throw new InvalidInputInfoException("Inserted a duplicate role name.");
    }
    // role is invalid
    if (!(Roles.contains(name))) {
      throw new InvalidInputInfoException("Inserted a invalid role name.");
    }
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      roleId = DatabaseInserter.insertRole(name, connection);
      connection.close();

    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return roleId;
  }

  /**
   * insert a new user to database.
   * 
   * @param name the name of the user you want to insert.
   * @param age the age of the user you want to insert.
   * @param address the address of the user you want to insert.
   * @param password the password of the user you want to insert.
   * @return -1 if the operation fails, userId otherwise.
   */
  public static int insertNewUser(String name, int age, String address, String password)
      throws InvalidInputInfoException {
    // TODO Implement this method as stated on the assignment sheet
    // hint: You should be using these three lines in your final code
    Connection connection = null;
    int userId = -1;
    // users name is null
    if (name == null) {
      throw new InvalidInputInfoException("Inserted a null user name.");
    }
    // age is negative
    if (age < 0) {
      throw new InvalidInputInfoException("Inserted a negative age for the user");
    }
    // address is too long
    if (address.length() > 100) {
      throw new InvalidInputInfoException("Inserted a address that is too long");
    }
    // password is null
    if (password == null) {
      throw new InvalidInputInfoException("Inserted a null password");
    }
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      userId = DatabaseInserter.insertNewUser(name, age, address, password, connection);
      connection.close();

    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return userId;
  }

  /**
   * insert a role to the given user.
   * 
   * @param userId the userId of the user.
   * @param roleId the roleId you want to insert to the given user.
   * @return -1 if the operation fails, userRoleId otherwise.
   * @throws InvalidInputInfoException if the user adds a role, user that already exists and if the
   *         user is already given a role.
   */
  public static int insertUserRole(int userId, int roleId) throws InvalidInputInfoException {
    Connection connection = null;
    int userRoleId = -1;
    boolean inRoleTable = DatabaseDriverHelper.inRoleTable(roleId);
    boolean inUserTable = DatabaseDriverHelper.inUserTable(userId);
    boolean userInRoleTable = DatabaseDriverHelper.userInRoleTable(userId);
    // check if the role exists
    if (inRoleTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing role id.");
    }
    // check if the user exists
    if (inUserTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing user id.");
    }
    // check if the user and role relationship already exists
    if (userInRoleTable == true) {
      throw new InvalidInputInfoException("The user already exists in the userrole table.");
    }
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      userRoleId = DatabaseInserter.insertUserRole(userId, roleId, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return userRoleId;
  }

  /**
   * insert an item to the database.
   * 
   * @param name the name of the item.
   * @param price the price of the item.
   * @return -1 if the operation fails, itemId otherwise.
   * @throws InvalidInputInfoException if the user inserts a null item name, a duplicate item, or a
   *         negative price of the item.
   */
  public static int insertItem(String name, BigDecimal price) throws InvalidInputInfoException {
    Connection connection = null;
    int itemId = -1;
    boolean inItemTable = DatabaseDriverHelper.inItemTable(name);
    // the item is valid
    if (!ItemTypes.contains(name)) {
      throw new InvalidInputInfoException("Insert a valid item.");
    }
    // check if the item name is null
    if (name == null) {
      throw new InvalidInputInfoException("Insert a null item name.");
    }
    // check if the item is a duplicate
    if (inItemTable == true) {
      throw new InvalidInputInfoException("Inserted a duplicate item.");
    }
    // check if the item is in ItemTypes.
    if (!ItemTypes.contains(name)) {
      throw new InvalidInputInfoException("We have not this item.");
    }
    // check if the price is positive
    if (price.compareTo(new BigDecimal(0)) < 1) {
      throw new InvalidInputInfoException("Inserted a negative price.");
    }
    // make sure the price is two decimal digits
    price = price.setScale(2, BigDecimal.ROUND_HALF_UP);
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      itemId = DatabaseInserter.insertItem(name, price, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return itemId;
  }

  /**
   * insert an item to the inventory of the database.
   * 
   * @param itemId the itemId of the item.
   * @param quantity the quantity of the item.
   * @return -1 if the operation fails, inventoryId otherwise.
   * @throws InvalidInputInfoException if the user inserts a item not in the database, a already
   *         existing item, and a negative quantity for the item.
   */
  public static int insertInventory(int itemId, int quantity) throws InvalidInputInfoException {
    Connection connection = null;
    int inventoryId = -1;
    boolean idInItemTable = DatabaseDriverHelper.inItemTableById(itemId);
    boolean itemInInventoryTable = DatabaseDriverHelper.itemInInventoryTable(itemId);
    // check if the item is valid
    if (idInItemTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing item.");
    }
    // check if the item exists in the inventory already.
    if (itemInInventoryTable == true) {
      throw new InvalidInputInfoException("Inserted a item that exists in the inventory already");
    }
    // check if the quantity is non negative
    if (quantity < 0) {
      throw new InvalidInputInfoException("Inserted a negative quantity");
    }
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      inventoryId = DatabaseInserter.insertInventory(itemId, quantity, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return inventoryId;
  }

  /**
   * insert a sale with the given userId and totalPrice to the database.
   * 
   * @param userId the userId of the user.
   * @param totalPrice the totalPrice of the items the user buys.
   * @return -1 if the operation fails, saleId otherwise.
   * @throws InvalidInputInfoException if the user enters a non existing user, a null total price,
   *         and a total price that is negative.
   */
  public static int insertSale(int userId, BigDecimal totalPrice) throws InvalidInputInfoException {
    // TODO Check if total price needs to be validated to be quantity*price
    Connection connection = null;
    int saleId = -1;
    boolean inUserTable = DatabaseDriverHelper.inUserTable(userId);
    // check if the user id exists
    if (inUserTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing user id");
    }
    // check if the total price is null
    if (totalPrice == null) {
      throw new InvalidInputInfoException("Inserted a null total price");
    }
    // check if the total price is positive
    if (totalPrice.floatValue() <= 0) {
      throw new InvalidInputInfoException("Inserted a negative total price");
    }
    // make sure the total price is two decimal digits
    totalPrice = totalPrice.setScale(2, BigDecimal.ROUND_HALF_UP);
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      saleId = DatabaseInserter.insertSale(userId, totalPrice, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return saleId;
  }

  /**
   * inserts a itemized sale into the database.
   * 
   * @param saleId the id of the sale to add items and quantity to.
   * @param itemId the id of the item to give to the itemized sale.
   * @param quantity the quantity of the item.
   * @return the itemized id if successful, false o/w.
   * @throws InvalidInputInfoException if user inserts a sale, item that isn't in the database, and
   *         a negative quantity for the item.
   */
  public static int insertItemizedSale(int saleId, int itemId, int quantity)
      throws InvalidInputInfoException {
    Connection connection = null;
    int itemizedId = -1;
    boolean inSaleTable = DatabaseDriverHelper.inSaleTable(saleId);
    boolean inItemTable = DatabaseDriverHelper.inItemTableById(itemId);
    // check if the sale id exists
    if (inSaleTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing sale id");
    }
    // check if the item id exists
    if (inItemTable == false) {
      throw new InvalidInputInfoException("Inserted a non existing item id");
    }
    // check if the quantity is positive
    if (quantity < 0) {
      throw new InvalidInputInfoException("Inserted a negative quantity");
    }
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      itemizedId = DatabaseInserter.insertItemizedSale(saleId, itemId, quantity, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return itemizedId;
  }

  /**
   * inserts a account given to a user in the database.
   * 
   * @param userId the id of the user to give the account to.
   * @return a id of the inserted account, returns -1 if it fails.
   * @throws InvalidInputInfoException if the user inserts a user
   *         that isn't in the database.
   */
  public static int insertAccount(int userId, boolean accountState) throws InvalidInputInfoException {
    int accountId = -1;
    boolean inUserTable = DatabaseDriverHelper.inUserTable(userId);
    // check if the user exists
    if (inUserTable == false) {
      throw new InvalidInputInfoException("Inserted a account with a non existing user id");
    }
    int roleId = DatabaseSelectHelper.getUserRoleId(userId);
    String name = DatabaseSelectHelper.getRoleName(roleId);
    if (!name.equalsIgnoreCase("CUSTOMER")) {
      throw new InvalidInputInfoException("this is not an customer Id");
    }
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      accountId = DatabaseInserter.insertAccount(userId, accountState, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return accountId;
  }

  /**
   * inserts a line into the account summary table.
   * 
   * @param accountId the id of account to store items to.
   * @param itemId the id of the item to add to the account.
   * @param quantity the quantity of the item.
   * @return a id of the inserted account summary, returns -1 if it fails.
   * @throws InvalidInputInfoException if the user inserts a item that doesn't exist, a account that
   *         doesn't exist and a negative quantity for the item.
   * @throws SQLException if there is something wrong with the connection.
   */
  public static int insertAccountLine(int accountId, int itemId, int quantity)
      throws InvalidInputInfoException, SQLException {
    int accountSummaryId = -1;
    boolean inItemTable = DatabaseDriverHelper.inItemTableById(itemId);
    boolean inAccountTable = DatabaseDriverHelper.inAccountTableById(accountId);
    // check if the item exists
    if (inItemTable == false) {
      throw new InvalidInputInfoException("Inserted a account summary with a non existing item id");
    }
    // check if the account exists
    if (inAccountTable == false) {
      throw new InvalidInputInfoException(
          "Inserted a account summary with a non existing account id");
    }
    // check if the quantity is negative
    if (quantity < 0) {
      throw new InvalidInputInfoException("Inserted an account summary with a negative quantity");
    }
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      accountSummaryId =
          DatabaseInserter.insertAccountLine(accountId, itemId, quantity, connection);
      connection.close();
    } catch (DatabaseInsertException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return accountSummaryId;
  }

}
