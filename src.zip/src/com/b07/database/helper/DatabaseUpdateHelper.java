package com.b07.database.helper;

import com.b07.collection.ItemTypes;
import com.b07.collection.Roles;
import com.b07.database.DatabaseUpdater;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

public class DatabaseUpdateHelper extends DatabaseUpdater {

  /**
   * Update the role name of a given role in the role table.
   * 
   * @param name the new name of the role.
   * @param id the current ID of the role.
   * @return true if successful, false otherwise.
   * @throws InvalidInputInfoException .
   */
  public static boolean updateRoleName(String name, int id) throws InvalidInputInfoException {
    if (!Roles.contains(name)) {
      throw new InvalidInputInfoException(name + "is not in Roles");
    }
    if (!DatabaseDriverHelper.inRoleTable(id)) {
      throw new InvalidInputInfoException(id + "is not in Role table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateRoleName(name, id, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }


  /**
   * .
   * 
   * @param name.
   * @param userId.
   * @throws InvalidInputInfoException . @return.
   */
  public static boolean updateUserName(String name, int userId) throws InvalidInputInfoException {
    if (name == null) {
      throw new InvalidInputInfoException("name cannot be null");
    }
    if (!DatabaseDriverHelper.inUserTable(userId)) {
      throw new InvalidInputInfoException(userId + "is not in User table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserName(name, userId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("cannot close the connection.");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param age .
   * @param userId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateUserAge(int age, int userId) throws InvalidInputInfoException {
    if (age <= 0) {
      throw new InvalidInputInfoException("age cannot be negative");
    }
    if (!DatabaseDriverHelper.inUserTable(userId)) {
      throw new InvalidInputInfoException(userId + "is not in User table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserAge(age, userId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("cannot close the connection.");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param address .
   * @param userId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateUserAddress(String address, int userId)
      throws InvalidInputInfoException {
    if (address == null || address.length() > 100) {
      throw new InvalidInputInfoException(
          "address cannot be null " + "and the length cannot greater than 100");
    }
    if (!DatabaseDriverHelper.inUserTable(userId)) {
      throw new InvalidInputInfoException(userId + "is not in User table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserAddress(address, userId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("cannot close the connection.");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param roleId .
   * @param userId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateUserRole(int roleId, int userId) throws InvalidInputInfoException {
    if (!DatabaseDriverHelper.inUserTable(userId)) {
      throw new InvalidInputInfoException(userId + " is not in our system");
    }
    if (!DatabaseDriverHelper.inRoleTable(roleId)) {
      throw new InvalidInputInfoException(" the id is not correct");
    }

    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateUserRole(roleId, userId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("cannot close the connection.");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param name .
   * @param itemId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateItemName(String name, int itemId) throws InvalidInputInfoException {
    if (!ItemTypes.contains(name)) {
      throw new InvalidInputInfoException(name + "is not in ItemTypes");
    }
    if (!DatabaseDriverHelper.inItemTableById(itemId)) {
      throw new InvalidInputInfoException(itemId + "is not in Item table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateItemName(name, itemId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param price .
   * @param itemId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateItemPrice(BigDecimal price, int itemId)
      throws InvalidInputInfoException {
    price = price.setScale(2, BigDecimal.ROUND_HALF_UP);
    if (price.compareTo(new BigDecimal(0)) < 1) {
      throw new InvalidInputInfoException("the price must greater than 0");
    }
    if (!DatabaseDriverHelper.inItemTableById(itemId)) {
      throw new InvalidInputInfoException(itemId + "is not in Item table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateItemPrice(price, itemId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }

  /**
   * .
   * 
   * @param quantity .
   * @param itemId .
   * @return .
   * @throws InvalidInputInfoException .
   */
  public static boolean updateInventoryQuantity(int quantity, int itemId)
      throws InvalidInputInfoException {
    if (quantity < 0) {
      throw new InvalidInputInfoException(" quantity cannot less than 0");
    }
    Inventory inventory = DatabaseSelectHelper.getInventory();
    HashMap<Item, Integer> map = inventory.getItemMap();
    boolean inInventoryTable = false;
    for (Item i : map.keySet()) {
      if (i.getId() == itemId) {
        inInventoryTable = true;
      }
    }
    if (inInventoryTable == false) {
      throw new InvalidInputInfoException("the item is not in inventory");
    }
    if (!DatabaseDriverHelper.inItemTableById(itemId)) {
      throw new InvalidInputInfoException(itemId + "is not in Item table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateInventoryQuantity(quantity, itemId, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }

  /**
   * update the status of the account with the given account id and the given boolean.
   * 
   * @param accountId the given account id.
   * @param active the given boolean representing the updating status of the account.
   * @return false if the operation fails, true otherwise.
   * @throws InvalidInputInfoException if the input account id is not in account table.
   */
  public static boolean updateAccountStatus(int accountId, boolean active)
      throws InvalidInputInfoException {
    if (!DatabaseDriverHelper.inAccountTableById(accountId)) {
      throw new InvalidInputInfoException(accountId + "is not in account table");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = DatabaseUpdater.updateAccountStatus(accountId, active, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }

  /**
   * Update the user's password.
   * @param password the given password
   * @param id the given user id
   * @return true if the input is valid and the operation is successful, false otherwise
   * @throws InvalidInputInfoException if the input is invalid
   */
  public static boolean updateUserPassword(String password, int id)
      throws InvalidInputInfoException {
    if (!DatabaseDriverHelper.inUserTable(id)) {
      throw new InvalidInputInfoException(id + " is not in our system");
    }
    Connection connection = null;
    boolean complete = false;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      complete = updateUserPassword(password, id, connection);
      connection.close();
    } catch (SQLException e) {
      System.out.println("can not close the exception");
    }
    return complete;
  }

}
