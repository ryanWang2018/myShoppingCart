package com.b07.database.helper;

import com.b07.database.DatabaseDriver;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.store.SalesLog;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;


public class DatabaseDriverHelper extends DatabaseDriver {

  public static Connection connectOrCreateDataBase() {
    return DatabaseDriver.connectOrCreateDataBase();
  }

  /**
   * It judges whether the userId is in the user table.
   * @param userId is an integer.
   * @return true if the id is in the user table.
   */
  public static boolean inUserTable(int userId) {
    boolean result = false;
    List<Integer> allUsersId = DatabaseSelectHelper.getAllUserId();
    for (Integer i : allUsersId) {
      if (i == userId) {
        result = true;
      }
    }
    return result;
  }


  /**
   * It judges whether the userId is in the userRole table.
   * @param userId is an integer.
   * @return true if the id is in the userRole table.
   */
  public static boolean userInRoleTable(int userId) {
    boolean result = false;
    if (DatabaseSelectHelper.getUserRoleId(userId) != -1) {
      result = true;
    }
    return result;
  }

  /**
   * It judges whether the roleId is in the role table.
   * @param roleId is an integer.
   * @return true if the id is in the role table.
   */
  public static boolean inRoleTable(int roleId) {
    // TODO Auto-generated method stub
    boolean result = false;
    List<Integer> allRoleId = DatabaseSelectHelper.getRoleIds();
    if (allRoleId.contains(roleId)) {
      result = true;
    }
    return result;
  }

  /**
   * It judges whether the itemId is in the inventory table.
   * @param itemId is an integer.
   * @return true if the id is in the inventory table.
   */
  public static boolean itemInInventoryTable(int itemId) {
    Inventory inventory = DatabaseSelectHelper.getInventory();
    if (inventory == null) {
      return false;
    }
    HashMap<Item, Integer> allItems = inventory.getItemMap();
    for (Item item : allItems.keySet()) {
      int id = item.getId();
      if (id == itemId) {
        return true;
      }
    }
    return false;

  }


  /**
   * It judges whether the name is in the item table.
   * @param name is a string.
   * @return true if the name is in the item table.
   */
  public static boolean inItemTable(String name) {
    boolean result = false;
    List<Item> allItem = DatabaseSelectHelper.getAllItems();
    for (Item i : allItem) {
      if (i.getName().equalsIgnoreCase(name)) {
        result = true;
      }
    }
    return result;
  }

  /**
   * It judges whether the itemId is in the item table.
   * @param itemId is an integer.
   * @return true if the id is in the item table.
   */
  public static boolean inItemTableById(int itemId) {
    boolean result = false;
    List<Item> allItem = DatabaseSelectHelper.getAllItems();
    for (Item i : allItem) {
      if (i.getId() == itemId) {
        result = true;
      }
    }
    return result;
  }

  /**
   * It judges whether the name is in the role table.
   * @param name is a string.
   * @return true if the name is in the role table.
   */
  public static boolean inRoleTablebyName(String name) {
    // check the given name is already in role table;
    boolean result = false;
    List<Integer> allRoleId = DatabaseSelectHelper.getRoleIds();
    for (Integer i : allRoleId) {
      String roleName = DatabaseSelectHelper.getRoleName(i);
      if (roleName.equalsIgnoreCase(name)) {
        result = true;
      }
    }
    return result;
  }
  
  /**
   * check the sale is in the sale table or not.
   * @param saleId the saleId of the sale.
   * @return boolean represents if the sale is in the table
   */
  public static boolean inSaleTable(int saleId) {
    SalesLog salesLog = DatabaseSelectHelper.getSales();
    List<Sale> allSales = salesLog.getAllSales();
    for (int i = 0; i < allSales.size(); i++) {
      Sale currentSale = allSales.get(i);
      int currentSaleId = currentSale.getId();
      if (currentSaleId == saleId) {
        return true;
      }
    }
    return false;
  }

  /**
   * check if the account id is in the account table.
   * 
   * @param accountId the account to check.
   * @return true if the account is in the table. false o/w.
   * @throws SQLException if there is a problem with the connection.
   */
  protected static boolean inAccountTableById(int accountId) {
    try {
      DatabaseSelectHelper.getAccountDetails(accountId);
    } catch (SQLException e) {
      return false;
    }
    return true;
  }


}
