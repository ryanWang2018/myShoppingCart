package com.b07.database.helper;

import com.b07.database.DatabaseSelector;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Inventory;
import com.b07.inventory.InventoryImpl;
import com.b07.inventory.Item;
import com.b07.inventory.ItemImpl;
import com.b07.store.AccountSummary;
import com.b07.store.AccountSummaryImpl;
import com.b07.store.Sale;
import com.b07.store.SaleImpl;
import com.b07.store.SalesLog;
import com.b07.store.SalesLogImpl;
import com.b07.users.Admin;
import com.b07.users.Customer;
import com.b07.users.User;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * The Class DatabaseSelectHelper.
 */

public class DatabaseSelectHelper extends DatabaseSelector {
  /**
   * It gets all the roleIds stored in the database.
   * 
   * @return ids, A list containing all the roleIds.
   */
  // get all the roleId from role table
  public static List<Integer> getRoleIds() {
    Connection connection = null;
    List<Integer> ids = new ArrayList<>();
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getRoles(connection);
      while (results.next()) {
        ids.add(results.getInt("ID"));
      }
      results.close();
      connection.close();
      return ids;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return ids;
  }

  /**
   * Gets the role name.
   *
   * @param roleId the role id
   * @return the role name
   */
  // -1 case existed
  public static String getRoleName(int roleId) {
    Connection connection = null;
    String role = null;
    if (roleId != -1) {
      try {
        connection = DatabaseDriverHelper.connectOrCreateDataBase();
        role = DatabaseSelector.getRole(roleId, connection);
        connection.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
      return role;
    } else {
      return null;
    }
  }
  
  /**
   * get a list of all of the user id.
   * @return a list of all of the user id.
   */
  public static List<Integer> getAllUserId() {
    List<Integer> allUser = new ArrayList<>();
    Connection connection = null;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUsersDetails(connection);
      while (results.next()) {
        int userId = results.getInt("ID");
        allUser.add(userId);
      }
      connection.close();
      return allUser;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return allUser;
  }


  /**
   * get a list of all of the role names.
   * @return a list of all of the role names.
   * @throws InvalidInputInfoException if the input is invalid.
   */
  public static List<String> getAllRoleName() throws InvalidInputInfoException {
    List<String> allRoleName = new ArrayList<>();
    List<Integer> allRoleId = DatabaseSelectHelper.getRoleIds();
    for (Integer i : allRoleId) {
      String name = DatabaseSelectHelper.getRoleName(i);
      allRoleName.add(name);
    }
    return allRoleName;
  }


  /**
   * Gets the user role id.
   *
   * @param userId the user id
   * @return the user role id
   */
  // -1 case existed
  public static int getUserRoleId(int userId) {
    Connection connection = null;
    int roleId = -1;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      roleId = DatabaseSelector.getUserRole(userId, connection);
      connection.close();
      return roleId;
    } catch (SQLException e) {
      // throw new exception here i.e. UserNotFoundException
    }
    return roleId;
  }

  /**
   * Gets the users by role.
   *
   * @param roleId the role id
   * @return the users by role
   * @throws InvalidInputInfoException if the input is invalid.
   */
  // get all the users by the
  // some problem with this code.
  public static List<Integer> getUsersByRole(int roleId) throws InvalidInputInfoException {
    List<Integer> userIds = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUsersByRole(roleId, connection);
      while (results.next()) {
        userIds.add(results.getInt("USERID"));
      }
      results.close();
      connection.close();
      return userIds;
    } catch (SQLException e) {
      // throw new exception here -i.e. InvalidInputException
      e.printStackTrace();
    }
    return userIds;
  }

  /**
   * Gets the users details.
   *
   * @return the users details
   * @throws InvalidInputInfoException if the input is invalid.
   */
  public static List<User> getUsersDetails() throws InvalidInputInfoException {
    List<User> users = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUsersDetails(connection);
      User user = null;
      while (results.next()) {
        int id = results.getInt("ID");
        String name = results.getString("NAME");
        int age = results.getInt("AGE");
        String add = results.getString("ADDRESS");
        int roleId = DatabaseSelectHelper.getUserRoleId(id);
        if (roleId != -1) {
          String roleName = DatabaseSelectHelper.getRoleName(roleId);
          if (roleName.equalsIgnoreCase("ADMIN")) {
            user = new Admin(id, name, age, add);
          } else if (roleName.equalsIgnoreCase("CUSTOMER")) {
            user = new Customer(id, name, age, add);
          }
          users.add(user);
        }
      }
      results.close();
      connection.close();
      return users;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return users;
  }

  /**
   * Gets the user details.
   *
   * @param userId the user id
   * @return the user details
   */
  // should not return newUser = null?
  public static User getUserDetails(int userId) {
    Connection connection = null;
    ResultSet results = null;
    User user = null;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      results = DatabaseSelector.getUsersDetails(connection);
      while (results.next()) {
        int id = results.getInt("ID");
        String name = results.getString("NAME");
        int age = results.getInt("AGE");
        String add = results.getString("ADDRESS");

        if (id == userId) {
          int roleId = DatabaseSelectHelper.getUserRoleId(id);
          if (roleId != -1) {
            String roleName = DatabaseSelectHelper.getRoleName(roleId);
            if (roleName.equalsIgnoreCase("ADMIN")) {
              user = new Admin(id, name, age, add);
            } else if (roleName.equalsIgnoreCase("CUSTOMER")) {
              user = new Customer(id, name, age, add);

            }
          }
        }
      }
      connection.close();
      results.close();
      return user;
    } catch (SQLException e) {
      // throw new UserNotFoundException
      e.printStackTrace();
    }
    return user;
  }

  /**
   * Gets the password.
   *
   * @param userId the user id
   * @return the password
   */
  // null password? no needed?
  public static String getPassword(int userId) {
    String password = null;
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      password = DatabaseSelector.getPassword(userId, connection);
      connection.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return password;
  }

  /**
   * Gets the all items.
   *
   * @return the all items
   */
  public static List<Item> getAllItems() {
    List<Item> items = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getAllItems(connection);
      while (results.next()) {
        int id = results.getInt("ID");
        Item item = getItem(id);
        items.add(item);
      }
      results.close();
      connection.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return items;
  }

  /**
   * Gets the item.
   *
   * @param itemId the item id
   * @return the item
   */
  // item null? no needed?
  public static Item getItem(int itemId) {
    Item item = null;
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getItem(itemId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        String name = results.getString("NAME");
        BigDecimal price = new BigDecimal(results.getString("PRICE"));
        item = new ItemImpl(id, name, price);
      }
    } catch (SQLException e) {
      // throw new exception ItemNotFoundException
      e.printStackTrace();
    }
    return item;
  }

  /**
   * Gets the inventory.
   *
   * @return the inventory
   */
  public static Inventory getInventory() {
    Inventory inventory = new InventoryImpl();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getInventory(connection);
      HashMap<Item, Integer> maps = new HashMap<>();
      while (results.next()) {
        int itemId = results.getInt("ITEMID");
        Item item = DatabaseSelectHelper.getItem(itemId);
        String strQuantity = results.getString("QUANTITY");
        Integer intQuantity = Integer.parseInt(strQuantity);
        maps.put(item, intQuantity);
      }
      inventory.setItemMap(maps);
    } catch (SQLException e) {
      e.printStackTrace();;
    }
    return inventory;
  }

  /**
   * Gets the inventory quantity.
   *
   * @param itemId the item id
   * @return the inventory quantity
   * @throws InvalidInputInfoException if the input is invalid.
   */
  // quantity initialized -1?
  public static int getInventoryQuantity(int itemId) throws InvalidInputInfoException {

    int quantity = -1;
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      quantity = DatabaseSelector.getInventoryQuantity(itemId, connection);
    } catch (SQLException e) {
      // throw new ItemNotFoundException
      e.printStackTrace();;
    }
    return quantity;
  }

  // SalesLog stores all the sales happened in the store
  /**
   * Gets the sales.
   *
   * @return the sales
   */
  // remove try catch block
  public static SalesLog getSales() {
    SalesLog salesLog = new SalesLogImpl();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getSales(connection);
      while (results.next()) {
        int id = results.getInt("ID");
        int userId = results.getInt("USERID");
        BigDecimal totalPrice = new BigDecimal(results.getString("TOTALPRICE"));
        User user = DatabaseSelectHelper.getUserDetails(userId);
        Sale sale = new SaleImpl(id, user, userId, totalPrice);
        salesLog.addSale(sale);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return salesLog;
  }


  /**
   * Gets the sale by id.
   *
   * @param saleId the sale id
   * @return the sale by id
   * @throws InvalidInputInfoException if the input is invalid.
   */
  // not properly implemented.
  public static Sale getSaleById(int saleId) throws InvalidInputInfoException {
    Sale sale = null;
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getSaleById(saleId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        int userId = results.getInt("USERID");
        BigDecimal price = new BigDecimal(results.getString("TOTALPRICE"));
        if (id == saleId) {
          User user = DatabaseSelectHelper.getUserDetails(userId);
          sale = new SaleImpl(id, user, userId, price);
        }
      }
      results.close();
      connection.close();
    } catch (SQLException e) {
      // throw new SaleNotFoundException
      e.printStackTrace();
    }
    return sale;
  }

  /**
   * Gets the sales to user.
   *
   * @param userId the user id
   * @return the sales to user
   */
  // for the method i modefied the given code by the author.
  public static List<Sale> getSalesToUser(int userId) {
    List<Sale> allSales = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelectHelper.getSalesToUser(userId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        int usersId = results.getInt("USERID");
        BigDecimal price = new BigDecimal(results.getString("TOTALPRICE"));
        if (usersId == userId) {
          User user = DatabaseSelectHelper.getUserDetails(userId);
          Sale sale = new SaleImpl(id, user, usersId, price);
          allSales.add(sale);
        }
      }
      results.close();
      connection.close();
    } catch (SQLException e) {
      // throw new UserNotFoundException
      e.printStackTrace();
    }
    return allSales;
  }

  /**
   * Gets the itemized sale by id.
   *
   * @param saleId the sale id
   */
  public static Sale getItemizedSaleById(int saleId) {
    Connection connection = null;
    try {
      connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getItemizedSaleById(saleId, connection);
      while (results.next()) {
        int itemId = results.getInt("ITEMID");
        int quantity = results.getInt("QUANTITY");
        if (id == saleId) {
          sale = new SaleImpl(id, itemId, quantity);
        }
      }
      results.close();
      connection.close();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        connection.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
    return sale;
  }

  /**
   * Gets the itemized sales.
   *
   * @param salesLog the sales log
   * @throws SQLException the SQL exception
   */
  // TODO
  public static void getItemizedSales(SalesLog salesLog) throws SQLException {
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getItemizedSales(connection);
    while (results.next()) {
      int saleId = results.getInt("SALEID");
      int itemId = results.getInt("ITEMID");
      int quantity = results.getInt("QUANTITY");
      for (Sale sale : salesLog.getAllSales()) {
        if ((saleId == sale.getId())) {
          Item item = DatabaseSelectHelper.getItem(itemId);
          sale.updateItemMap(item, quantity);
        }
      }
    }
    results.close();
    connection.close();
  }

  /**
   * gets all the accounts associated with a given user.
   * 
   * @param userId the id of the user to retrieve accounts from.
   * @return all the accounts of a given user.
   * @throws SQLException if there is something wrong with the connection.
   */
  public static List<Integer> getUserAccounts(int userId) {
    List<Integer> allAccounts = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUserAccounts(userId, connection);
      while (results.next()) {
        int accountId = results.getInt("ID");
        allAccounts.add(accountId);
      }
      results.close();
      connection.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return allAccounts;
  }

  /**
   * gets the account details of a specified account.
   * 
   * @param accountId the id to get the info for.
   * @return a account summary of the account.
   * @throws SQLException if there is something wrong with the connection.
   */
  public static AccountSummary getAccountDetails(int accountId) throws SQLException {
    AccountSummary accountSummary = new AccountSummaryImpl();
    Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
    ResultSet results = DatabaseSelector.getAccountDetails(accountId, connection);
    while (results.next()) {
      int id = results.getInt("ACCTID");
      int itemId = results.getInt("ITEMID");
      int quantity = results.getInt("QUANTITY");
      accountSummary.setShoppingCart(itemId, quantity);
      accountSummary.setAccountId(id);
    }
    return accountSummary;
  }

  /**
   * gets the list of id of all active accounts belong to the given user.
   * 
   * @param userId is the id of the given user
   * @return the list of active account id
   */
  public static List<Integer> getUserActiveAccounts(int userId) {
    List<Integer> allActiveAccounts = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUserActiveAccounts(userId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        allActiveAccounts.add(id);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return allActiveAccounts;
  }
  
  /**
  * gets the list of id of all inactive accounts belong to the given user.
  * 
  * @param userId is the id of the given user
  * @return the list of inactive account id
  */
  public static List<Integer> getUserInactiveAccounts(int userId) {
    List<Integer> allActiveAccounts = new ArrayList<>();
    try {
      Connection connection = DatabaseDriverHelper.connectOrCreateDataBase();
      ResultSet results = DatabaseSelector.getUserInactiveAccounts(userId, connection);
      while (results.next()) {
        int id = results.getInt("ID");
        allActiveAccounts.add(id);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return allActiveAccounts;
  }

}
