package com.b07.users;

import com.b07.database.helper.DatabaseSelectHelper;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
  private List<Integer> cusAccounts = new ArrayList<>();

  public Customer(int id, String name, int age, String address) {
    super(id, name, age, address);
  }

  public void addToAccount(int accountId) {
    cusAccounts.add(accountId);
  }

  /**
   * This method gets the accounts of the customer.
   * 
   * @return a list of accounts of the customer
   * @throws SQLException is thrown when the select method has error
   */
  public List<Integer> getAccount() throws SQLException {
    List<Integer> listInt = DatabaseSelectHelper.getUserAccounts(this.getId());
    return listInt;
  }
  
  /**
   * This method gets the active accounts of the customer.
   * 
   * @return a list of active accounts id of the customer
   * @throws SQLException is thrown when the select method has error
   */
  public List<Integer> getActiveAccount() throws SQLException {
    List<Integer> listInt = DatabaseSelectHelper.getUserActiveAccounts(this.getId());
    return listInt;
  }
  
}
