package com.b07.users;

public class Admin extends User {

  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private boolean authenticated;

  public Admin(int id, String name, int age, String address) {
    super(id, name, age, address);
  }

  public Admin(int id, String name, int age, String address, boolean authenticate) {
    super(id, name, age, address);
    this.authenticated = authenticate;
  }

  public int getId() {
    return this.id;
  }
  
  public String getName() {
    return this.name;
  }
  
  public int getAge() {
    return this.age;
  }
  
  public String getAddress() {
    return this.address;
  }
  
  public int getRoleId() {
    return this.roleId;
  }
  
  public boolean getAuthenticated() {
    return this.authenticated;
  }
}