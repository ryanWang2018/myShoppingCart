package com.b07.users;

public class Employee extends User {

  private int id;
  private String name;
  private int age;
  private int roleId;
  private boolean authenticated;

  public Employee(int id, String name, int age, String address) {
    super(id, name, age, address);
  }

  public Employee(int id, String name, int age, String address, boolean authenticated) {
    super(id, name, age, address);
    this.authenticated = authenticated;
  }

  public int getId() {
    return this.id;
  }

  public String getName() {
    return this.name;
  }

  public int getAge() {
    return this.age;
  }

  public int getRoleId() {
    return this.roleId;
  }

  public boolean getAuthenticated() {
    return this.authenticated;
  }
}