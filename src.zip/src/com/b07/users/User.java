package com.b07.users;

import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.security.PasswordHelpers;

public abstract class User {

  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private boolean authenticated;

  /**
   * Constructor for the abstract class User.
   * 
   * @param id is an integer larger than 0.
   * @param name is a string which is contained in ROLES.
   * @param age is an integer larger than 0.
   * @param address is a string which is not null an the length is less than 100.
   */
  public User(int id, String name, int age, String address) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.address = address;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public int getRoleId() {
    return roleId;
  }

  public String getAddress() {
    return this.address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  /**
   * The method is to judge whether the user can login.
   * 
   * @param password is a string.
   * @return true if the user can login.
   */
  public final boolean authenticate(String password) {
    this.authenticated =
        PasswordHelpers.comparePassword(DatabaseSelectHelper.getPassword(this.id), password);
    return this.authenticated;
  }

  /**
   * The method update the information of the user.
   * 
   * @throws InvalidInputInfoException is thrown if the input is invalid.
   */
  public void update() throws InvalidInputInfoException {
    DatabaseUpdateHelper.updateUserAddress(this.getAddress(), id);
    DatabaseUpdateHelper.updateUserAge(this.age, id);
    DatabaseUpdateHelper.updateUserName(this.name, id);
    DatabaseUpdateHelper.updateUserRole(this.roleId, id);
  }
}
