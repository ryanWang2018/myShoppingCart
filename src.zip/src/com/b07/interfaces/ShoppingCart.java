package com.b07.interfaces;

import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Item;
import com.b07.users.Customer;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class ShoppingCart {

  private HashMap<Item, Integer> items = new HashMap<>();
  private Customer customer;
  private BigDecimal total = new BigDecimal("0");
  private static final BigDecimal TAXRATE = new BigDecimal("1.13");
  private int accountId = -1;

  /**
   * the constructor of ShoppingCart.
   * 
   * @param customer the customer of the shopping cart.
   */
  public ShoppingCart(Customer customer) {
    this.customer = customer;

  }

  /**
   * Create a customer's account id and add it to the customer's account id list.
   * 
   * @return the new generated account id.
   * @throws InvalidInputInfoException if the input is invalid.
   */
  public int createAccount() throws InvalidInputInfoException {
    int accountId = DatabaseInsertHelper.insertAccount(this.customer.getId(), true);
    this.customer.addToAccount(accountId);
    return accountId;
  }

  /**
   * Get the quantity of the given item.
   * 
   * @param item the name of the item.
   * @return the number of the quantity.
   */
  public int getQuantity(Item item) {
    return items.get(item);
  }

  /**
   * Get the item by the given name.
   * 
   * @param name the name of the item.
   * @return the item by the given name.
   */
  public Item getItemByName(String name) {
    Item item = null;
    for (Item i : items.keySet()) {
      String itemName = i.getName();
      if (itemName.equalsIgnoreCase(name) == true) {
        item = i;
      }
    }
    return item;
  }

  /**
   * Add the item with the quantity to the database.
   * 
   * @param item the item you want to add.
   * @param quantity the quantity of the item.
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public void addItem(Item item, int quantity) throws InvalidInputInfoException {
    int itemId = item.getId();
    int inventoryQuantity = DatabaseSelectHelper.getInventoryQuantity(itemId);
    if (inventoryQuantity < quantity) {
      System.out.println("your quantity are more than our storage");
      throw new InvalidInputInfoException();
    } else if (quantity < 1) {
      System.out.println("quantity cannot less than 1");
      throw new InvalidInputInfoException();
    } else {
      boolean itemIn = this.itemInCart(item);
      if (itemIn) {
        for (Item i : this.items.keySet()) {
          if (i.getId() == item.getId()) {
            quantity = this.items.get(i) + quantity;
            if (quantity > inventoryQuantity) {
              System.out.println("your quantity are more than our storage");
              throw new InvalidInputInfoException();
            }
            this.items.put(i, quantity);
          }
        }
      } else {
        items.put(item, quantity);
      }
    }
  }

  /**
   * when the customer choose to exit, this method will add all the items that the customer not buy
   * to the last account id to the customer's account id list, and insert to the account table in
   * the database.
   * 
   * @throws InvalidInputInfoException if the input is invalid.
   * @throws SQLException if the database option fails.
   */
  public void exit() throws SQLException {
    List<Item> notBuy = this.getItems();
    if (notBuy != null) {
      List<Integer> accounts = this.customer.getActiveAccount();
      if (!accounts.isEmpty()) {
        int lastAccount = accounts.get((accounts.size()) - 1);
        if (DatabaseSelectHelper.getAccountDetails(lastAccount).getAccountSummary().keySet()
            .size() != 0) {
          try {
            lastAccount = this.createAccount();
          } catch (InvalidInputInfoException e) {
            e.printStackTrace();
          }
        }
        for (Item i : notBuy) {
          int quantity = getQuantity(i);
          int itemId = i.getId();
          try {
            DatabaseInsertHelper.insertAccountLine(lastAccount, itemId, quantity);
          } catch (InvalidInputInfoException e) {
            e.printStackTrace();
          } catch (SQLException e) {
            e.printStackTrace();
          }
        }
      }
    }
  }

  /**
   * Remove the given item from the database by the given quantity.
   * 
   * @param item the item you want to remove.
   * @param quantity the quantity of the item you want to remove.
   */
  public void removeItem(Item item, int quantity) {
    boolean in = false;
    for (Item i : this.items.keySet()) {
      if (i.getId() == item.getId()) {
        in = true;
        int number = this.items.get(i);
        number = number - quantity;
        if (number <= 0) {
          this.items.remove(i);
        } else {
          this.items.put(i, number);
        }
      }
    }
    if (!in) {
      System.out.println("this item is not in your shopping cart");
    }
  }

  /**
   * Get the list of the items in the shopping cart.
   * 
   * @return the list of the items in the shopping cart.
   */
  public List<Item> getItems() {
    if (this.items.isEmpty()) {
      return null;
    }
    List<Item> result = new ArrayList<>(items.keySet());
    return result;
  }

  /**
   * Get the total price of the shopping cart.
   * 
   * @return the total price of the shopping cart.
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public BigDecimal getTotal() throws InvalidInputInfoException {
    // TODO Auto-generated method stub
    BigDecimal price = new BigDecimal("0");
    Set<Item> allItems = (Set<Item>) items.keySet();
    for (Item i : allItems) {
      BigDecimal quantity = new BigDecimal(items.get(i));


      BigDecimal priceForOne = i.getPrice().multiply(quantity);
      price = price.add(priceForOne);
    }
    price = price.multiply(TAXRATE);
    price.setScale(2, RoundingMode.HALF_UP);
    this.total = price;
    return total;
  }


  public BigDecimal getTaxRate() {
    return TAXRATE;
  }

  /**
   * Check out the customer of the shopping cart with the given customer.
   * 
   * @param shoppingCart the shopping cart to check out.
   * @return true successfully check out customer, return false otherwise.
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public boolean checkOut(ShoppingCart shoppingCart) throws InvalidInputInfoException {
    boolean result = false;
    Customer customer = shoppingCart.getCustomer();
    int userId = customer.getId();
    BigDecimal total = shoppingCart.getTotal();
    int saleId = -1;
    try {
      saleId = DatabaseInsertHelper.insertSale(userId, total);
    } catch (InvalidInputInfoException e) {
      return false;
    }
    for (Item i : shoppingCart.getItems()) {
      int itemId = i.getId();
      int num = DatabaseSelectHelper.getInventoryQuantity(itemId);
      int quantity = shoppingCart.getQuantity(i);
      int updateQuantity = num - quantity;
      int itemizedId = DatabaseInsertHelper.insertItemizedSale(saleId, itemId, quantity);
      result = DatabaseUpdateHelper.updateInventoryQuantity(updateQuantity, itemId);
      if (itemizedId == -1 || result == false) {
        return false;
      }
    }
    int accountId = shoppingCart.getAccountId();
    if (accountId != -1) {
      DatabaseUpdateHelper.updateAccountStatus(accountId, false);
    }
    shoppingCart.clearCart();
    System.out.println("You check out successfully!");
    return true;
  }


  public void clearCart() {
    this.items.clear();
  }

  public HashMap<Item, Integer> getMap() {
    return this.items;
  }

  /**
   * the method is to check whether the item is in the cart.
   * 
   * @param item is the item you want to check
   * @return true if the item is in the cart
   */
  public boolean itemInCart(Item item) {
    boolean result = false;
    for (Item i : this.items.keySet()) {
      if (i.getId() == item.getId()) {
        result = true;
      }
    }
    return result;
  }
  
  public void setAccountId(int accountId) {
    this.accountId = accountId;
  }
  
  public int getAccountId() {
    return this.accountId;
  }
  
  public Customer getCustomer() {
    return this.customer;
  }
  
  public void setItems(HashMap<Item, Integer> map) {
    this.items = map;
  }

}

