package com.b07.interfaces;

import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.store.SalesHistory;
import com.b07.store.SalesHistoryImpl;
import com.b07.store.SalesLog;
import com.b07.users.User;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminInterface {

  /**
   * the method will get the sales history.
   * 
   * @return sales history
   */
  public SalesHistory getSalesHistory() {
    // put info needed into the sales history
    SalesLog allSales = DatabaseSelectHelper.getSales();
    SalesHistory salesHistory = new SalesHistoryImpl();
    salesHistory.setSalesLog(allSales);
    return salesHistory;
  }

  /**
   * the method will print the sales history.
   * 
   * @param salesHistory is the historic sales information
   * @throws InvalidInputInfoException is thrown if the input is invalid.
   * @throws SQLException is thrown if the SQL has error.
   */
  public void printSalesHistory(SalesHistory salesHistory)
      throws InvalidInputInfoException, SQLException {
    // get all the info needed to print>
    SalesLog salesLog = salesHistory.getSalesLog();
    DatabaseSelectHelper.getItemizedSales(salesLog);
    List<Sale> allSales = salesLog.getAllSales();
    int finalTotalPrice = 0;
    HashMap<String, Integer> itemSummary = new HashMap<String, Integer>();
    // print out the sales history
    for (int i = 0; i < allSales.size(); i++) {
      Sale currentSale = allSales.get(i);
      User customer = currentSale.getUser();
      String customerName = customer.getName();
      System.out.println("Customer: " + customerName);
      int saleId = currentSale.getId();
      System.out.println("Purchase Number: " + saleId);
      BigDecimal totalPrice = currentSale.getTotalPrice();
      System.out.println("Total Purchase Price: " + totalPrice);
      finalTotalPrice += totalPrice.floatValue();
      HashMap<Item, Integer> itemsBought = currentSale.getItemMap();
      for (Map.Entry<Item, Integer> a : itemsBought.entrySet()) {
        Item item = a.getKey();
        int quantity = a.getValue();
        String itemName = item.getName();
        System.out.println("Itemized Breakdown: " + itemName + " : " + quantity);
        // check if the item is in the item summary
        // if it is then update the quantity with the new quantity
        // else just put the quantity in
        if (itemSummary.containsKey(itemName)) {
          int currentQuantity = itemSummary.get(itemName);
          quantity = quantity + currentQuantity;
          itemSummary.put(itemName, quantity);
        } else {
          itemSummary.put(itemName, quantity);
        }
      }
      System.out.println("--------------------------------------------");
    }
    // print out the item summary
    for (Map.Entry<String, Integer> itemSummaryToPrint : itemSummary.entrySet()) {
      String itemName = itemSummaryToPrint.getKey();
      int quantity = itemSummaryToPrint.getValue();
      System.out.println("Number " + itemName + " Sold: " + quantity);
    }
    System.out.println("TOTAL SALES: " + finalTotalPrice);
  }
  
  /**
   * Show the current active accounts with the given user id.
   * @param userId the given user id
   */
  public static void showAcitveAccounts(int userId) {
    List<Integer> accList = DatabaseSelectHelper.getUserActiveAccounts(userId);
    String ids = "";
    if (accList.size() == 0) {
      System.out.println("User " + userId + " has no active account.");
    } else {
      for (int i: accList) {
        ids = ids + i + " ";
      }
      System.out.println("All active accounts of user " + userId + ": " + ids);
    }
  }
  
  /**
   * Show the current inactive accounts with the given user id.
   * @param userId the given user id
   */
  public static void showInacitveAccounts(int userId) {
    List<Integer> accList = DatabaseSelectHelper.getUserInactiveAccounts(userId);
    String ids = "";
    if (accList.size() == 0) {
      System.out.println("User " + userId + " has no inactive account.");
    } else {
      for (int i: accList) {
        ids = ids + i + " ";
      }
      System.out.println("All inactive accounts of user " + userId + ": " + ids);
    }
  }
  
  /**
   * The method will re-stock the inventory.
   * 
   * @param item is the item you want to re-stock
   * @param quantity is the quantity of the item you want to re-stock
   * @return true if the operation success
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static boolean restockInventory(Item item, int quantity) throws InvalidInputInfoException {
    // check if the item is in the table, if it isn't then add it, if it is then update it.
    int itemId = item.getId();
    boolean inInventoryTable = DatabaseDriverHelper.itemInInventoryTable(itemId);
    if (inInventoryTable == false) {
      DatabaseInsertHelper.insertInventory(itemId, quantity);
    } else {
      DatabaseUpdateHelper.updateInventoryQuantity(quantity, itemId);
    }
    return true;
  }

  /**
   * the method will create a customer.
   * 
   * @param name is the name of the customer
   * @param age is the age of the customer
   * @param address is the address of the customer
   * @param password is the password of the customer
   * @return the id of the customer
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static int createCustomer(String name, int age, String address, String password)
      throws InvalidInputInfoException {
    int roleId = -1;
    if (!DatabaseDriverHelper.inRoleTablebyName("Customer")) {
      roleId = DatabaseInsertHelper.insertRole("Customer");
    } else {
      List<Integer> allRoleIds = DatabaseSelectHelper.getRoleIds();
      for (int i : allRoleIds) {
        if (DatabaseSelectHelper.getRoleName(i).equalsIgnoreCase("Customer")) {
          roleId = i;
        }
      }
    }
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    return userId;
  }

  /**
   * the method will create a employee.
   * 
   * @param name is the name of the employee
   * @param age is the age of the employee
   * @param address is the address of the employee
   * @param password is the password of the employee
   * @return the id of the employee
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static int createAdmin(String name, int age, String address, String password)
      throws InvalidInputInfoException {
    int roleId = -1;
    List<Integer> allRoleIds = DatabaseSelectHelper.getRoleIds();
    for (int i : allRoleIds) {
      if (DatabaseSelectHelper.getRoleName(i).equalsIgnoreCase("ADMIN")) {
        roleId = i;
      }
    }
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    return userId;
  }

  /**
   * the method will create an account for the customer given.
   * 
   * @param userId is the id of the customer
   * @return the id of the account we create
   */
  public static int createAccount(int userId) {
    int accountId = 0;
    try {
      accountId = DatabaseInsertHelper.insertAccount(userId);
    } catch (InvalidInputInfoException e) {
      accountId = -1;
    }
    return accountId;
  }

}
