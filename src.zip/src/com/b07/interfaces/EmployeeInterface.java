package com.b07.interfaces;

import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;
import com.b07.users.Employee;
import java.util.List;

public class EmployeeInterface {
  private Employee currentEmployee;
  private Inventory inventory;

  public EmployeeInterface(Employee employee, Inventory inventory) {
    this.currentEmployee = employee;
    this.setInventory(inventory);
  }

  public EmployeeInterface(Inventory inventory) {
    this.setInventory(inventory);
  }

  public void setCurrentEmployee(Employee employee) {
    this.currentEmployee = employee;
  }

  /**
   * the method will judge whether there is a current employee.
   * 
   * @return true if there is a current employee
   */
  public boolean hasCurrentEmployee() {
    if (currentEmployee == null) {
      return false;
    }
    return true;
  }

  /**
   * The method will re-stock the inventory.
   * 
   * @param item is the item you want to re-stock
   * @param quantity is the quantity of the item you want to re-stock
   * @return true if the operation success
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public boolean restockInventory(Item item, int quantity) throws InvalidInputInfoException {
    // check if the item is in the table, if it isn't then add it, if it is then update it.
    int itemId = item.getId();
    boolean inInventoryTable = DatabaseDriverHelper.itemInInventoryTable(itemId);
    if (inInventoryTable == false) {
      DatabaseInsertHelper.insertInventory(itemId, quantity);
    } else {
      DatabaseUpdateHelper.updateInventoryQuantity(quantity, itemId);
    }
    return true;
  }

  /**
   * the method will create a customer.
   * 
   * @param name is the name of the customer
   * @param age is the age of the customer
   * @param address is the address of the customer
   * @param password is the password of the customer
   * @return the id of the customer
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static int createCustomer(String name, int age, String address, String password)
      throws InvalidInputInfoException {
    int roleId = -1;
    if (!DatabaseDriverHelper.inRoleTablebyName("Customer")) {
      roleId = DatabaseInsertHelper.insertRole("Customer");
    } else {
      List<Integer> allRoleIds = DatabaseSelectHelper.getRoleIds();
      for (int i : allRoleIds) {
        if (DatabaseSelectHelper.getRoleName(i).equalsIgnoreCase("Customer")) {
          roleId = i;
        }
      }
    }
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    EmployeeInterface.createAccount(userId);
    return userId;
  }

  /**
   * the method will create a employee.
   * 
   * @param name is the name of the employee
   * @param age is the age of the employee
   * @param address is the address of the employee
   * @param password is the password of the employee
   * @return the id of the employee
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static int createEmployee(String name, int age, String address, String password)
      throws InvalidInputInfoException {
    int roleId = -1;
    List<Integer> allRoleIds = DatabaseSelectHelper.getRoleIds();
    for (int i : allRoleIds) {
      if (DatabaseSelectHelper.getRoleName(i).equalsIgnoreCase("EMPLOYEE")) {
        roleId = i;
      }
    }
    int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
    DatabaseInsertHelper.insertUserRole(userId, roleId);
    return userId;
  }

  /**
   * the method will create an account for the customer given.
   * 
   * @param userId is the id of the customer
   * @return the id of the account we create
   */
  public static int createAccount(int userId) {
    int accountId = 0;
    try {
      accountId = DatabaseInsertHelper.insertAccount(userId, true);
    } catch (InvalidInputInfoException e) {
      accountId = -1;
    }
    return accountId;
  }

  public Inventory getInventory() {
    return inventory;
  }

  public void setInventory(Inventory inventory) {
    this.inventory = inventory;
  }

}
