package com.b07.collection;

import java.util.ArrayList;
import java.util.List;

public enum ItemTypes {
  FISHING_ROD("Fishing rod"), HOCKEY_STICK("Hockey stick"), SKATES("skates"), RUNNING_SHOES(
      "Running shoes"), PROTEIN_BAR("Protein bar");

  private String itemName;

  ItemTypes(String itemName) {
    this.itemName = itemName;
  }

  public String getItemName() {
    return itemName;
  }

  /**
   * 
   * @param name the name of the item.
   * @return the item.
   */
  public static ItemTypes fromString(String name) {
    for (ItemTypes item : ItemTypes.values()) {
      if (item.itemName.equalsIgnoreCase(name)) {
        return item;
      }
    }
    return null;
  }

  /**
   * print the Item.
   * @return all items list.
   */
  public static List<String> printItem() {
    List<String> allItems = new ArrayList<>();

    int number = 0;
    for (ItemTypes item : ItemTypes.values()) {
      System.out.println(number + item.getItemName());
      allItems.add(item.getItemName());
      number += 1;
    }
    return allItems;
  }

  /**
   * 
   * @param name the name of the item.
   * @return true if ItemTypes contains the name of the item, false otherwise.
   */
  public static boolean contains(String name) {
    for (ItemTypes i : ItemTypes.values()) {
      if (i.itemName.equalsIgnoreCase(name)) {
        return true;
      }
    }
    return false;
  }

}
