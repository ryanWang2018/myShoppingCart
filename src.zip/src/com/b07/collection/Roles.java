package com.b07.collection;

public enum Roles {
  ADMIN("ADMIN"), CUSTOMER("CUSTOMER");

  private String role;

  Roles(String role) {
    this.role = role;
  }

  public String getRole() {
    return role;
  }

  /**
   * 
   * @param role the role name.
   * @return the role type by the given role name.
   */
  public static Roles fromString(String role) {
    for (Roles roles : Roles.values()) {
      if (roles.role.equalsIgnoreCase(role)) {
        return roles;
      }
    }
    return null;
  }

  /**
   * 
   * @param role the role name.
   * @return true if Roles contains the role name, false otherwise.
   */
  public static boolean contains(String role) {
    for (Roles roles : Roles.values()) {
      if (roles.role.equalsIgnoreCase(role)) {
        return true;
      }
    }
    return false;
  }

}
