package com.b07.exceptions;

public class InvalidInputInfoException extends Exception {

  private static final long serialVersionUID = 1L;

  public InvalidInputInfoException() {
    super();
  }

  public InvalidInputInfoException(String mag) {
    super(mag);
  }

}
