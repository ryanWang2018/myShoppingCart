package com.b07.driver;

import com.b07.collection.ItemTypes;
import com.b07.database.helper.DatabaseDriverHelper;
import com.b07.database.helper.DatabaseInsertHelper;
import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.database.helper.DatabaseUpdateHelper;
import com.b07.exceptions.InvalidInputInfoException;
import com.b07.interfaces.AdminInterface;
import com.b07.interfaces.ShoppingCart;
import com.b07.inventory.Inventory;
import com.b07.inventory.Item;
import com.b07.inventory.ItemImpl;
import com.b07.security.PasswordHelpers;
import com.b07.store.AccountSummary;
import com.b07.store.SalesHistory;
import com.b07.users.Admin;
import com.b07.users.Customer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public class Driver {
  private static String DIGIT_ONLY = "\\d+";

  /**
   * the constructor of AdminInterface.
   * 
   * @param adminInterface the administrator interface.
   * @throws InvalidInputInfoException is thrown if the input is invalid
   */
  public static void runArgvOne(AdminInterface adminInterface) throws InvalidInputInfoException {
    printAdminMenu();
    String option = readOption();
    switch (option) {
      case "1":
        // Make new User, i am consider this as a customer account,
        // create the customer and map it to the customer role table.
        String name = getName();
        int age = getAge();
        String address = getAddress();
        String password = getPassword();
        try {
          int customerId = AdminInterface.createCustomer(name, age, address, password);
          System.out.println("The customer id is " + customerId);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          System.out.println("the information is not valid to create customer, try again");
          runArgvOne(adminInterface);
        }
        runArgvOne(adminInterface);
        break;
      case "2":
        // Make new account, i am consider this is general account.
        // need to implement the createAccount in AdminInterface.
        int customerId = getUserId();
        int accountId = -1;
        accountId = AdminInterface.createAccount(customerId);
        if (accountId == -1) {
          System.out.println("the id is not valid please try again");
          runArgvOne(adminInterface);
        }
        System.out.println("the customer: " + customerId + " now has a account:" + accountId);
        runArgvOne(adminInterface);
        break;
      case "3":
        // Make new Administrator
        String names = getName();
        int ages = getAge();
        String addresss = getAddress();
        String passwords = getPassword();
        try {
          int emId = AdminInterface.createAdmin(names, ages, addresss, passwords);
          System.out.println("The admin id is " + emId);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          System.out.println("the information is not valid to create admin, try again");
          runArgvOne(adminInterface);
        }
        runArgvOne(adminInterface);
        break;
      case "4":
        // Re-stock Inventory
        Item item = getItem();
        int quantity = getQuantity();
        try {
          AdminInterface.restockInventory(item, quantity);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          runArgvOne(adminInterface);
        }
        runArgvOne(adminInterface);
        break;
      case "5":
        SalesHistory salesHistory = adminInterface.getSalesHistory();
        System.out.println("the list of sale");
        try {
          try {
            adminInterface.printSalesHistory(salesHistory);
          } catch (SQLException e) {
            e.printStackTrace();
          }
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
        }
        runArgvOne(adminInterface);
        break;
      case "6":
        System.out.println("Please provide user id");
        BufferedReader reader6 = new BufferedReader(new InputStreamReader(System.in));
        try {
          int userId = Integer.parseInt(reader6.readLine());
          if (!DatabaseDriverHelper.inUserTable(userId)) {
            System.out.println("The id is not in user table");
            throw new InvalidInputInfoException("The id is not in user table");
          }
          int roleId = DatabaseSelectHelper.getUserRoleId(userId);
          String roleName = DatabaseSelectHelper.getRoleName(roleId);
          if (!roleName.equalsIgnoreCase("CUSTOMER")) {
            System.out.println("this is not an customer Id");
            throw new InvalidInputInfoException("this is not an customer Id");
          }
          AdminInterface.showAcitveAccounts(userId);
        } catch (NumberFormatException | IOException e) {
          System.out.println("Input is invalid, please try again.");
        } catch (InvalidInputInfoException e) {
          System.out.println("Input invalid. Please try again.");
        } finally {
          runArgvOne(adminInterface);
        }
        break;
      case "7":
        System.out.println("Please provide user id");
        BufferedReader reader7 = new BufferedReader(new InputStreamReader(System.in));
        try {
          int userId = Integer.parseInt(reader7.readLine());
          if (!DatabaseDriverHelper.inUserTable(userId)) {
            System.out.println("The id is not in user table");
            throw new InvalidInputInfoException("The id is not in user table");
          }
          int roleId = DatabaseSelectHelper.getUserRoleId(userId);
          String roleName = DatabaseSelectHelper.getRoleName(roleId);
          if (!roleName.equalsIgnoreCase("CUSTOMER")) {
            System.out.println("this is not an customer Id");
            throw new InvalidInputInfoException("this is not an customer Id");
          }
          AdminInterface.showInacitveAccounts(userId);
        } catch (NumberFormatException | IOException e) {
          System.out.println("Input is invalid, please try again.");
        } catch (InvalidInputInfoException e) {
          System.out.println("Input invalid. Please try again.");
        } finally {
          runArgvOne(adminInterface);
        }
        break;
      case "0":
        System.out.println("thanks for using this system");
        break;
      default:
        System.out.println("Sorry, your in select number is not in our manu, try again!");
        runArgvOne(adminInterface);
        break;
    }



  }
  
  /**
   * insert the first administrator to the database, as part of the
   * initialization of the database.
   */
  public static void inserFirstAdmin() {
    System.out.println("Please provide information for the admin");
    String name = getName();
    int age = getAge();
    String address = getAddress();
    String password = getPassword();
    try {
      // insert the user to the users table.
      int userId = DatabaseInsertHelper.insertNewUser(name, age, address, password);
      // insert the user to the role table.
      int roleId = DatabaseInsertHelper.insertRole("ADMIN");
      // insert the user to the userRoleTable.
      DatabaseInsertHelper.insertUserRole(userId, roleId);
      System.out.println("Successful add an admin to system with id:" + userId);
    } catch (InvalidInputInfoException e) {
      e.printStackTrace();
      inserFirstAdmin();
    }

  }

  /**
   * get the user id and the user given password and check if the user
   * is an customer and the given password is correct.
   * @return the customer.
   */
  public static Customer customerLogIn() {
    Customer customer = null;
    int userId = getUserId();
    String passWord = getPassword();
    boolean inRoleTable = false;
    inRoleTable = DatabaseDriverHelper.userInRoleTable(userId);
    if (inRoleTable == false) {
      System.out.println("the customer id is not in db, please try again");
      customer = customerLogIn();
      // if any of the previous two bool false, call adminLogIn again.
    } else {
      // check the user is admin type
      boolean inCustomer = isCustomer(userId);
      if (inCustomer == true) {
        // check the pass word
        String dbPassWord = DatabaseSelectHelper.getPassword(userId);
        boolean trueEmployee = PasswordHelpers.comparePassword(dbPassWord, passWord);
        if (trueEmployee == true) {
          // create the admin;
          customer = (Customer) DatabaseSelectHelper.getUserDetails(userId);
        } else {
          System.out.println("the password is not correct, please try again");
          customer = customerLogIn();
        }
      } else {
        System.out.println("the id not an Customer, please try again");
        customer = customerLogIn();
      }
    }
    return customer;
  }

  /**
   * get the user id and the user given password and check if the user
   * is an administrator and the given password is correct.
   * @return the administrator.
   */
  public static Admin adminLogIn() {
    Admin admin = null;
    int userId = getUserId();
    String passWord = getPassword();
    boolean inRoleTable = false;
    inRoleTable = DatabaseDriverHelper.userInRoleTable(userId);
    if (inRoleTable == false) {
      System.out.println("the admin id is not in db, please try again");
      admin = adminLogIn();
      // if any of the previous two bool false, call adminLogIn again.
    } else {
      // check the user is admin type
      boolean inAdmin = isAdmin(userId);
      if (inAdmin == true) {
        // check the pass word
        String dbPassWord = DatabaseSelectHelper.getPassword(userId);
        boolean trueAdmin = PasswordHelpers.comparePassword(dbPassWord, passWord);
        if (trueAdmin == true) {
          // create the admin;
          admin = (Admin) DatabaseSelectHelper.getUserDetails(userId);
        } else {
          System.out.println("the password is not correct, please try again");
          admin = adminLogIn();
        }
      } else {
        System.out.println("the id not an admin, please try again");
        admin = adminLogIn();
      }
    }
    return admin;
  }

  private static void printEmployeeMenu() {
    System.out.println("1. authenticate new employee");
    System.out.println("2. Make new User");
    System.out.println("3. Make new account");
    System.out.println("4. Make new Employee");
    System.out.println("5. Restock Inventory");
    System.out.println("6. Exit");
  }

  /**
   * run the several options as the user chooses in the employee login mode.
   * @param employeeInterface the given employeeInterface.
   */
  public static void runEmployee(EmployeeInterface employeeInterface) {
    printEmployeeMenu();
    String option = readOption();
    switch (option) {
      case "1": // authenticate new employee
        boolean isEmployee = false;
        Employee employee = null;
        while (isEmployee == false) {
          int id = getUserId();
          boolean inEmployee = isEmployee(id);
          if (inEmployee == true) {
            System.out.println(isEmployee(id));
            employee = (Employee) DatabaseSelectHelper.getUserDetails(id);
            isEmployee = true;
          }
          System.out.println("this is not a valid employee id, please try again!");

        }
        employeeInterface.setCurrentEmployee(employee);
        runEmployee(employeeInterface);
        break;
      case "2":
        // Make new User, i am consider this as a customer account,
        // since the user of this system at this level are only employee and customer
        // and we already has option to create employee, therefore this will
        // create the customer and map it to the customer role table.
        String name = getName();
        int age = getAge();
        String address = getAddress();
        String password = getPassword();
        try {
          int customerId = EmployeeInterface.createCustomer(name, age, address, password);
          System.out.println("The customer id is " + customerId);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          System.out.println("the information is not valid to create customer, try again");
          runEmployee(employeeInterface);
        }
        runEmployee(employeeInterface);
        break;
      case "3":
        // Make new account, i am consider this is gereral account.
        // need to implement the createAccount in EmployeeInterface.
        int customerId = getUserId();
        int accountId = -1;
        accountId = EmployeeInterface.createAccount(customerId);
        if (accountId == -1) {
          System.out.println("the id is not valid please try again");
          runEmployee(employeeInterface);
        } 
        System.out.println("the customer: " + customerId + " now has a account: " + accountId);
        runEmployee(employeeInterface);
        break;
      case "4":
        // Make new Employee
        String names = getName();
        int ages = getAge();
        String addresss = getAddress();
        String passwords = getPassword();
        try {
          int emId = EmployeeInterface.createEmployee(names, ages, addresss, passwords);
          System.out.println("The employee id is " + emId);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          System.out.println("the information is not valid to create employee, try again");
          runEmployee(employeeInterface);
        }
        runEmployee(employeeInterface);
        break;
      case "5":
        // Restock Inventory
        Item item = getItem();
        int quantity = getQuantity();
        try {
          employeeInterface.restockInventory(item, quantity);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          runEmployee(employeeInterface);
        }
        runEmployee(employeeInterface);
        break;
      case "6":
        // exit
        // back to the menu that choose login customer or employee.
        Driver.runElseArgv();
        break;
      default:
        System.out.println("Soory, your in select number is not in our manu, try again!");
        runEmployee(employeeInterface);
        break;
    }
  }

  private static Item getItem() {

    List<String> list = ItemTypes.printItem();
    System.out.println("please choose the option!");
    String option1 = readOption();
    int choose = Integer.parseInt(option1);
    Item item = null;
    int itemId = -1;
    if (choose >= 0 && (choose <= list.size() - 1)) {
      String name = list.get(choose);
      String num = getPrice();
      BigDecimal price = new BigDecimal(num);
      try {
        // try to get the item id to create the item object.
        if (DatabaseDriverHelper.inItemTable(name)) {
          List<Item> allItem = DatabaseSelectHelper.getAllItems();
          for (Item i : allItem) {
            if (i.getName().equalsIgnoreCase(name)) {
              itemId = i.getId();
            }
          }
          DatabaseUpdateHelper.updateItemPrice(price, itemId);
        }
        itemId = DatabaseInsertHelper.insertItem(name, price);
        item = new ItemImpl(itemId, name, price);
      } catch (InvalidInputInfoException e) {
        // situation where the item is in the item table.
        List<Item> listItem = DatabaseSelectHelper.getAllItems();
        for (Item i : listItem) {
          if (i.getName().equalsIgnoreCase(name)) {
            itemId = i.getId();
            item = i;
          }
        }
      }
      if (itemId != -1) {
        item = DatabaseSelectHelper.getItem(itemId);
      }
    } else {
      System.out.println("something wrong with the inventory, try again");
      item = getItem();
    }
    return item;
  }

  private static void printMenuForShoppingCart() {
    System.out.println("1. List current items in cart");
    System.out.println("2. Add a quantity of an item to the cart");
    System.out.println("3. Check total price of items in the cart");
    System.out.println("4. Remove a quantity of an item from the cart");
    System.out.println("5. check out");
    System.out.println("6. create an account ");
    System.out.println("7. Restore the previous shoppingCart");
    System.out.println("8. Exit");

  }
  
  /**
   * run the options of shopping cart with the given shopping cart.
   * @param shoppingCart the given shopping cart.
   */
  public static void runShoppingCart(ShoppingCart shoppingCart) {
    printMenuForShoppingCart();
    String option = readOption();
    switch (option) {
      case "1":
        List<Item> items = shoppingCart.getItems();
        if (items == null) {
          System.out.println("There is no item in your cart.");
        } else {
          System.out.println("ID    Name    Price    Quantity");
          for (Item i : items) {
            System.out.println(i.getId() + "    " + i.getName() + "    " + i.getPrice() + "    "
                + shoppingCart.getMap().get(i));
          }
        }
        runShoppingCart(shoppingCart);
        break;
      case "2":
        runShoppingCartCaseTwo(shoppingCart);
        runShoppingCart(shoppingCart);
        break;
      case "3":
        // Check total price of items in the cart
        try {
          BigDecimal totalPrice = shoppingCart.getTotal();
          System.out.println(totalPrice);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
          runShoppingCart(shoppingCart);
        }
        runShoppingCart(shoppingCart);
        break;
      case "4":
        // Remove a quantity of an item from the cart
        // get the items that the customer wants to remove
        List<Item> shoppingItems = shoppingCart.getItems();
        int index = 0;
        System.out.println("Index:  Name  Quantity");
        for (Item i : shoppingItems) {
          System.out.println(index + ":  " + i.getName() + "  " + shoppingCart.getMap().get(i));
          index += 1;
        }
        index = shoppingItems.size();
        String options = readOption();
        int option1 = Integer.parseInt(options);
        boolean exit = false;
        while (exit == false) {
          if (option1 < index) {
            int quantity = getQuantity();
            int itemId = shoppingItems.get(option1).getId();
            Item removeitem = DatabaseSelectHelper.getItem(itemId);
            shoppingCart.removeItem(removeitem, quantity);
            exit = true;
          } else {
            System.out.println("Please choose the option again");
            exit = true;
          }
        }
        runShoppingCart(shoppingCart);
        break;
      case "5":
        // check out
        try {
          shoppingCart.checkOut(shoppingCart);
        } catch (InvalidInputInfoException e1) {
          e1.printStackTrace();
        }
        runShoppingCart(shoppingCart);
        break;
      case "6":
        // create an account.
        try {
          int countId = shoppingCart.createAccount();
          System.out.println("the acound id is : " + countId);
        } catch (InvalidInputInfoException e) {
          e.printStackTrace();
        }
        runShoppingCart(shoppingCart);
        break;
      case "7":
        // restore the previous shopping cart
        try {
          List<Integer> accounts = shoppingCart.getCustomer().getActiveAccount();
          if (!accounts.isEmpty()) {
            int lastAccount = accounts.get((accounts.size()) - 1);
            shoppingCart.setAccountId(lastAccount);
            AccountSummary accSummary = DatabaseSelectHelper.getAccountDetails(lastAccount);
            shoppingCart.setItems(accSummary.getShoppingCart());
            System.out.println("Restore the previous shopping cart successfully!");
          } else {
            System.out.println("You have no active account!");
          }
        } catch (SQLException e1) {
          e1.printStackTrace();
        }
        runShoppingCart(shoppingCart);
        break;
      case "8":
        // Exit
        try {
          shoppingCart.exit();
        } catch (SQLException e) {
          e.printStackTrace();
        }
        break;
      default:
        System.out.println("Sorry, your in select number is not in our manu, try again!");
        runShoppingCart(shoppingCart);
        break;
    }
  }


  /**
   * run the options of the else situation of the argument.
   */
  public static void runElseArgv() {
    Customer customer = customerLogIn();
    ShoppingCart shoppingCart = new ShoppingCart(customer);
    Driver.runShoppingCart(shoppingCart);
  }



  private static String getName() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Please enter your name:");
    String input = null;
    try {
      input = reader.readLine();
    } catch (IOException e) {
      e.printStackTrace();
    }
    String name = input;
    return name;
  }

  private static int getQuantity() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    boolean validAge = false;
    String age = null;
    while (validAge == false) {
      System.out.println("Please enter the quantity for the item:");
      String input = null;
      try {
        input = reader.readLine();
      } catch (IOException e) {
        e.printStackTrace();
      }
      if (input.matches(DIGIT_ONLY)) {
        age = input;
        validAge = true;
      } else {
        System.out.println("the quantity should be a number");
      }
    }
    int quantity = Integer.parseInt(age);
    return quantity;
  }

  private static String getPrice() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    boolean validAge = false;
    String prices = null;
    while (validAge == false) {
      System.out.println("Please enter the price for the item:");
      String input = null;
      try {
        input = reader.readLine();
      } catch (IOException e) {
        e.printStackTrace();
      }
      try {
        Double price = Double.valueOf(input);
        prices = price.toString();
        validAge = true;
        return prices;
      } catch (NumberFormatException e) {
        System.out.println("the price should be a number");
      }
    }
    return prices;
  }

  private static int getAge() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    boolean validAge = false;
    String age = null;
    while (validAge == false) {
      System.out.println("Please enter your age:");
      String input = null;
      try {
        input = reader.readLine();
      } catch (IOException e) {
        e.printStackTrace();
      }
      if (input.matches(DIGIT_ONLY)) {
        age = input;
        validAge = true;
      } else {
        System.out.println("the age should be a number");
      }
    }
    int intAge = Integer.parseInt(age);
    return intAge;
  }

  private static String getPassword() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Please enter your Password:");
    String input = null;
    try {
      input = reader.readLine();
    } catch (IOException e) {
      e.printStackTrace();
    }
    String passWord = input;
    return passWord;
  }

  private static String getAddress() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    String address = null;
    boolean validAddress = false;
    while (validAddress == false) {
      System.out.println("Please enter your address:");
      String input = null;
      try {
        input = reader.readLine();
      } catch (IOException e) {
        e.printStackTrace();
      }
      if (input.length() <= 100) {
        address = input;
        validAddress = true;
      } else {
        System.out.println("the address should be less than 100 characters");
      }
    }
    return address;
  }

  private static String readOption() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    String input = null;
    try {
      input = reader.readLine();
    } catch (IOException e) {
      e.printStackTrace();
    }
    String option = input;
    return option;
  }



  private static void printAdminMenu() {
    System.out.println("1. make new User");
    System.out.println("2. make new account");
    System.out.println("3. make new Admin");
    System.out.println("4. restock Inventory");
    System.out.println("5. print sale");
    System.out.println("6. check all active accounts of a user");
    System.out.println("7. check all inactive accounts of a user");
    System.out.println("0. exit");
  }

  private static int getUserId() {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    boolean validId = false;
    String userIds = null;
    String input = null;
    while (validId == false) {
      System.out.println("Please enter your id:");
      try {
        input = reader.readLine();
      } catch (IOException e) {
        e.printStackTrace();
      }
      if (input.matches(DIGIT_ONLY)) {
        userIds = input;
        validId = true;
      } else {
        System.out.println("the id should be a number");
      }
    }
    int userId = Integer.parseInt(userIds);
    return userId;
  }

  private static boolean isAdmin(int userId) {
    boolean result = false;
    int roleId = -1;
    if (DatabaseDriverHelper.inUserTable(userId) == false) {
      return false;
    }
    roleId = DatabaseSelectHelper.getUserRoleId(userId);
    String name = null;
    name = DatabaseSelectHelper.getRoleName(roleId);
    if (name.equalsIgnoreCase("admin") == true) {
      result = true;
    }
    return result;
  }

  private static boolean isCustomer(int userId) {
    boolean result = false;
    int roleId = -1;
    if (DatabaseDriverHelper.inUserTable(userId) == false) {
      return false;
    }
    roleId = DatabaseSelectHelper.getUserRoleId(userId);
    String name = null;
    name = DatabaseSelectHelper.getRoleName(roleId);
    if (name.equalsIgnoreCase("Customer") == true) {
      result = true;
    }
    return result;
  }

  /**
   * check if the input user id is an employee's id.
   * @param userId the given user id.
   * @return true if the input user id is an employee's id, false otherwise.
   */
  public static boolean isEmployee(int userId) {
    boolean result = false;
    int roleId = -1;
    if (DatabaseDriverHelper.inUserTable(userId) == false) {
      return false;
    }
    roleId = DatabaseSelectHelper.getUserRoleId(userId);
    String name = null;
    name = DatabaseSelectHelper.getRoleName(roleId);
    if (name.equalsIgnoreCase("EMPLOYEE") == true) {
      result = true;
    }
    return result;
  }

  /**
   * print the remaining inventory after running the given shopping cart.
   * @param shoppingCart the given shopping cart.
   */
  public static void printInventory(ShoppingCart shoppingCart) {
    System.out.println("ID    Name    Price    Quantity");
    Inventory inventory = DatabaseSelectHelper.getInventory();
    Set<Item> allItem = inventory.getItemMap().keySet();
    for (Item i : allItem) {
      int quantity = inventory.getItemMap().get(i);
      for (Item j : shoppingCart.getMap().keySet()) {
        if (j.getId() == i.getId()) {
          quantity = quantity - shoppingCart.getMap().get(j);
        }
      }
      System.out
          .println(i.getId() + "    " + i.getName() + "    " + i.getPrice() + "    " + quantity);
    }
  }

  /**
   * run the options of the given shopping cart in case two.
   * @param shoppingCart the given shopping cart.
   */
  public static void runShoppingCartCaseTwo(ShoppingCart shoppingCart) {
    printInventory(shoppingCart);
    try {
      System.out.println("Print the id of item you want to add");
      BufferedReader readerId = new BufferedReader(new InputStreamReader(System.in));
      int id = Integer.parseInt(readerId.readLine());
      Item item = DatabaseSelectHelper.getItem(id);
      if (item == null) {
        System.out.println("We have no this item, please try again!");
        runShoppingCartCaseTwo(shoppingCart);
      } else {
        System.out.println("Print the quantity");
        BufferedReader readerQuantity = new BufferedReader(new InputStreamReader(System.in));
        int quantity = Integer.parseInt(readerQuantity.readLine());
        shoppingCart.addItem(item, quantity);
        System.out.println("You have added the item successfully!");
      }
    } catch (InvalidInputInfoException e1) {
      System.out.println("Your input is invalid, please try again.");
      runShoppingCartCaseTwo(shoppingCart);
    } catch (IOException e2) {
      e2.printStackTrace();
    }
  }

}
