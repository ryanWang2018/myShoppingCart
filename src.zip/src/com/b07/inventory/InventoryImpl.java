package com.b07.inventory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class InventoryImpl implements Inventory, java.io.Serializable {

  private static final long serialVersionUID = 5838380807823304598L;
  private HashMap<Item,Integer> map = new HashMap<>();
  private int total = 0;

  public InventoryImpl(){
    
  }
  
  public InventoryImpl(Item item, int quantity) {
    this.map.put(item, quantity);
  }
  
  @Override
  public HashMap<Item, Integer> getItemMap() {
    return map;
  }

  @Override
  public void setItemMap(HashMap<Item, Integer> itemMap) {
    this.map = itemMap;
  }

  @Override
  public void updateMap(Item item, Integer value) {
    this.map.put(item, value);
  }

  @Override
  public int getTotalItems() {
    Collection<Integer> allValue = new ArrayList<>();
    allValue = map.values();
    total = 0;
    for (Integer i: allValue) {
      total += i;
    }
    return total;
  }

  @Override
  public void setTotalItems(int total) {
    this.total = total;    
  }

}
