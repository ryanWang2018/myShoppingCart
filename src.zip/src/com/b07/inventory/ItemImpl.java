package com.b07.inventory;

import java.math.BigDecimal;

public class ItemImpl implements Item, java.io.Serializable {

  private static final long serialVersionUID = 8002120410210746471L;
  private int id = 0;
  private String name;
  private BigDecimal price;

  public ItemImpl(int id){
  }
  
  /**
   * the constructor of ItemImpl.
   * @param id the id of the item.
   * @param name the name of the item.
   * @param price the price of the item.
   */
  public ItemImpl(int id, String name, BigDecimal price) {
    this.id = id;
    this.name = name;
    this.price = price;
  }
  
  @Override
  public int getId() {
    return id;
  }

  @Override
  public void setId(int id) {
    this.id = id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public void setName(String name) {
    this.name = name;
  }

  @Override
  public BigDecimal getPrice() {
    return price;
  }

  @Override
  public void setPrice(BigDecimal price) {
    this.price = price;
  }


}
