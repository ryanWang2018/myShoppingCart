package com.b07.store;

import com.b07.driver.Driver;
import com.b07.interfaces.AdminInterface;
import java.sql.Connection;

public class SalesApplication {
  /**
   * This is the main method to run your entire program! Follow the "Pulling it together"
   * instructions to finish this off.
   * 
   * @param argv unused.
   */
  /**
  * This is the main method to run your entire program! Follow the "Pulling it together"
  * instructions to finish this off.
  * 
  * @param argv unused.
  */
  public static void main(String[] argv) {

    Connection connection = DatabaseDriverExtender.connectOrCreateDataBase();
    if (connection == null) {
      System.out.print("NOOO");
    }
    try {
      if (argv.length != 0 && argv[0].equals("-1")) {
        DatabaseDriverExtender.initialize(connection);
        Driver.inserFirstAdmin();
        System.out.println("Congratulation! you can explore other features in the system");
      } else if (argv.length != 0 && argv[0].equals("1")) {
        System.out.println("You are in admin mode");
        // this is for the admin mode, which will let admin login first
        Driver.adminLogIn();
        AdminInterface adminInterface = new AdminInterface();
        Driver.runArgvOne(adminInterface);
      } else {
        System.out.println("You are in Customer mode ");
        Driver.runElseArgv();
      }  
    } catch (Exception e) {
      System.out.println("Something went wrong ");
    } finally {
      try {
        connection.close();
      } catch (Exception e) {
        System.out.println("Looks like it was closed already ");
      }
    }
  }
}