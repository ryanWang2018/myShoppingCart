package com.b07.store;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SalesLogImpl implements SalesLog {

  private List<Sale> allSale = new ArrayList<>();
  private HashMap<Integer, Integer> itemBought = new HashMap<Integer, Integer>();
  private HashMap<Integer, Integer> salesRow = new HashMap<Integer, Integer>();

  @Override
  public void addSale(Sale sale) {
    this.allSale.add(sale);
  }

  @Override
  public List<Sale> getAllSales() {
    return allSale;
  }

  @Override
  public void addItemBought(HashMap<Integer, Integer> itemBought) {
    this.itemBought = itemBought;
  }

  @Override
  public HashMap<Integer, Integer> getItemBought() {
    return itemBought;
  }

  @Override
  public HashMap<Integer, Integer> getAllSalesRow() {
    return this.salesRow;
  }

  @Override
  public void addSalesRow(HashMap<Integer, Integer> salesRow) {
    this.salesRow = salesRow;
  }


}
