package com.b07.store;

import com.b07.exceptions.InvalidInputInfoException;
import com.b07.inventory.Item;
import com.b07.users.User;
import java.math.BigDecimal;
import java.util.HashMap;


public class SaleImpl implements Sale {
  private int saleId;
  private int itemId;
  private int quantity;
  private int userId;
  private User user;
  private BigDecimal totalPrice = new BigDecimal("0");
  private HashMap<Item, Integer> allItems = new HashMap<Item, Integer>();

  /**
   * Constructor.
   * 
   * @param id is the id of sale
   * @param userId is the id of the user
   * @param price is the total price
   */
  public SaleImpl(int id, int userId, BigDecimal price) {
    this.saleId = id;
    this.setUserId(userId);
    this.totalPrice = price;
  }


  /**
   * Constructor.
   * 
   * @param id is the id of sale
   * @param itemId is the id of item
   * @param quantity is the quantity of item
   */
  public SaleImpl(int id, int itemId, int quantity) {
    this.saleId = id;
    this.setItemId(itemId);
    this.setQuantity(quantity);
  }

  /**
   * Constructor.
   * 
   * @param id is the id of sale
   * @param user is the user
   * @param price is the total price
   * @param maps shows the items and the quantities
   */
  public SaleImpl(int id, User user, BigDecimal price, HashMap<Item, Integer> maps) {
    this.saleId = id;
    this.user = user;
    this.totalPrice = price;
    this.allItems = maps;
  }

  /**
   * Constructor.
   * 
   * @param id is the id of sale
   * @param user is the user
   * @param userId is the id of the user
   * @param price is the total price
   */
  public SaleImpl(int id, User user, int userId, BigDecimal price) {
    this.saleId = id;
    this.user = user;
    this.setUserId(userId);
    this.totalPrice = price;
  }

  @Override
  public int getId() {
    return this.saleId;
  }

  @Override
  public void setId(int id) {
    this.saleId = id;
  }

  @Override
  public User getUser() throws InvalidInputInfoException {
    return this.user;
  }


  @Override
  public void setUser(User user) {
    this.user = user;

  }

  @Override
  public BigDecimal getTotalPrice() {
    return this.totalPrice;
  }

  @Override
  public void setTotalPrice(BigDecimal price) {
    this.totalPrice = price;
  }

  @Override
  public HashMap<Item, Integer> getItemMap() {
    return this.allItems;
  }

  @Override
  public void setItemMap(HashMap<Item, Integer> itemMap) {
    this.allItems = itemMap;
  }

  @Override
  public void updateItemMap(Item item, int quantity) {
    allItems.put(item, quantity);
  }


  public int getItemId() {
    return itemId;
  }


  public void setItemId(int itemId) {
    this.itemId = itemId;
  }


  public int getQuantity() {
    return quantity;
  }


  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }


  public int getUserId() {
    return userId;
  }


  public void setUserId(int userId) {
    this.userId = userId;
  }
}
