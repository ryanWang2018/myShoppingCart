package com.b07.store;

public interface SalesHistory {

  public void setSalesLog(SalesLog salesLog);

  public SalesLog getSalesLog();

}
