package com.b07.store;

import com.b07.inventory.Item;
import java.util.HashMap;

public interface AccountSummary {

  public void setAccountId(int accountId);
  
  public int getAccountId();
  
  public HashMap<Integer, Integer> getAccountSummary();
  
  public void setShoppingCart(int itemId, int quantity);
  
  public HashMap<Item, Integer> getShoppingCart();
  
}
