package com.b07.store;

public class SalesHistoryImpl implements SalesHistory {
  private SalesLog salesLog;

  @Override
  public void setSalesLog(SalesLog salesLog) {
    this.salesLog = salesLog;
  }

  @Override
  public SalesLog getSalesLog() {
    return salesLog;
  }


}
