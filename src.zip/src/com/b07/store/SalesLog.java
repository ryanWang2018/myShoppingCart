package com.b07.store;

import java.util.HashMap;
import java.util.List;


public interface SalesLog {

  public void addSale(Sale sale);

  public List<Sale> getAllSales();

  // maps item id to quantity
  public HashMap<Integer, Integer> getItemBought();

  public void addItemBought(HashMap<Integer, Integer> itemBought);

  public HashMap<Integer, Integer> getAllSalesRow();

  // maps user id to sale id
  public void addSalesRow(HashMap<Integer, Integer> salesRow);

}
