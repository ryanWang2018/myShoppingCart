package com.b07.store;

import com.b07.database.helper.DatabaseSelectHelper;
import com.b07.inventory.Item;
import java.util.HashMap;

public class AccountSummaryImpl implements AccountSummary {
  private int accountId;
  private HashMap<Integer, Integer> accountSummary = new HashMap<>();

  @Override
  public void setAccountId(int accountId) {
    this.accountId = accountId;
  }

  @Override
  public int getAccountId() {
    return this.accountId;
  }

  @Override
  public HashMap<Integer, Integer> getAccountSummary() {
    return this.accountSummary;
  }

  @Override
  public void setShoppingCart(int itemId, int quantity) {
    this.accountSummary.put(itemId, quantity);
  }
  
  /**
   * Get the shopping cart from the account summary.
   */
  public HashMap<Item, Integer> getShoppingCart() {
    HashMap<Item, Integer> shoppingCart = new HashMap<>();
    for (int i: this.accountSummary.keySet()) {
      Item item = DatabaseSelectHelper.getItem(i);
      int quantity = this.accountSummary.get(i);
      shoppingCart.put(item, quantity);
    }
    return shoppingCart;
  }


}
